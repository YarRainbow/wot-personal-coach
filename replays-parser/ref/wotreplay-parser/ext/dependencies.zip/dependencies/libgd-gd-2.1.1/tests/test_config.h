#define GDTEST_TOP_DIR "D:\\Develop\\libgd-gd-2.1.1\\tests" 
#define snprintf _snprintf 
